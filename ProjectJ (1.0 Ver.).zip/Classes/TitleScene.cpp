#include "SimpleAudioEngine.h"
#include "TitleScene.h"
#include "Stage1Scene.h"
USING_NS_CC;

Scene* TitleScene::createScene()
{
    return TitleScene::create();
}

static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in TitleSceneScene.cpp\n");
}

bool TitleScene::init()
{
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto buttonItem0 = MenuItemImage::create(
                                           "Title//buttonNormal.png",
                                           "Title//buttonClick.png",
                                           CC_CALLBACK_1(TitleScene::menuStartCallback, this));
	buttonItem0->setPosition(Vec2(640, 300));
	auto buttonLabel0 = Label::createWithSystemFont("���� ����", "HY�Ÿ���", 32, Size(250, 145), TextHAlignment::CENTER);
	buttonLabel0->setPosition(Vec2(160, -20));
	buttonItem0->addChild(buttonLabel0,2);

	auto buttonItem1 = MenuItemImage::create(
		"Title//buttonNormal.png",
		"Title//buttonClick.png",
		CC_CALLBACK_1(TitleScene::menuCloseCallback, this));
	buttonItem1->setPosition(Vec2(640,200));
	auto buttonLabel1 = Label::createWithSystemFont("������ ", "HY�Ÿ���", 32, Size(250, 145), TextHAlignment::CENTER);
	buttonLabel1->setPosition(Vec2(160, -20));
	buttonItem1->addChild(buttonLabel1, 2);

    // create menu, it's an autorelease object
    auto menu = Menu::create(buttonItem0, buttonItem1, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);
    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label

	auto label = Label::createWithSystemFont("Project J","Thonburi", 80, Size(650, 150), TextHAlignment::CENTER);
    label->setPosition(Vec2(640,500));
	label->enableBold();
	label->enableShadow(Color4B::BLACK, Size(2, -2));
    this->addChild(label, 1);
    
    // add "TitleScene" splash screen"
    auto backGround = Sprite::create("Title//backGround.png");
	backGround->setAnchorPoint(Vec2(0.0f, 0.0f));

	backGround->setPosition(Vec2(0,0));
    this->addChild(backGround, 0);
    return true;
}

void TitleScene::menuStartCallback(Ref* pSender)
{
	Director::getInstance()->replaceScene(Stage1Scene::createScene());
}

void TitleScene::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
