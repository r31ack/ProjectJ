#include "Stage1Scene.h"
#include "SimpleAudioEngine.h"
#include "TitleScene.h"
USING_NS_CC;

Scene* Stage1Scene::createScene()
{
	return Stage1Scene::create();
}

void Stage1Scene::loadTileMap()
{
	m_tileMap = CCTMXTiledMap::create("tileSet.tmx");
	this->setAnchorPoint(Vec2(0.0f, 0.0f));
	this->addChild(m_tileMap, 0);
	m_tileMapLayer = m_tileMap->layerNamed("Tile Layer 1");		// tiled���� ������ Ÿ�� ���̾������ ���̾� ������ ��´�.

	m_playerObject = m_tileMap->getObjectGroup("Objects");
	createFixtures(m_tileMapLayer);
}

bool Stage1Scene::init()
{									
	PhysicsEngine::GetInstance()->createWorld();

	m_player = new Player;
	m_player->init();
	addChild(m_player->getSprite(), 1);
	m_player->createPhysicsBody(PhysicsEngine::GetInstance()->getWorld());

	registInputEvent();			// �̺�Ʈ ���
	this->schedule(schedule_selector(Stage1Scene::update),0.016f);	// ������Ʈ ������ ����

	loadTileMap();	// Ÿ�ϸ� �ε�

	m_referenceLabel = Label::createWithSystemFont("Reference", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_referenceLabel->setPosition(Vec2(230, 70));
	this->addChild(m_referenceLabel, 1);
	m_testLabel = Label::createWithSystemFont("Tile", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_testLabel->setPosition(Vec2(230, 50));
	this->addChild(m_testLabel, 1);
	m_mouseLabel = Label::createWithSystemFont("Mouse", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_mouseLabel->setPosition(Vec2(230, 30));
	this->addChild(m_mouseLabel, 1);

	return true;
}

void Stage1Scene::registInputEvent()
{
	auto mouse_listener = EventListenerMouse::create();							
	mouse_listener->onMouseDown = CC_CALLBACK_1(Stage1Scene::OnMouseDown, this);
	mouse_listener->onMouseUp = CC_CALLBACK_1(Stage1Scene::OnMouseUp, this);
	mouse_listener->onMouseMove = CC_CALLBACK_1(Stage1Scene::OnMouseMove, this);
	mouse_listener->onMouseScroll = CC_CALLBACK_1(Stage1Scene::OnMouseScroll, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(mouse_listener, this);
	auto key_listener = EventListenerKeyboard::create();
	key_listener->onKeyPressed = CC_CALLBACK_2(Stage1Scene::OnKeyPress, this);
	key_listener->onKeyReleased = CC_CALLBACK_2(Stage1Scene::OnKeyUp, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(key_listener, this);		
}

void Stage1Scene::createFixtures(cocos2d::CCTMXLayer* layer)
{
	CCSize layerSize = layer->getLayerSize();
	for (int y = 0; y < layerSize.height; y++)
	{
		for (int x = 0; x < layerSize.width; x++)
		{
			CCSprite* tileSprite = layer->tileAt(ccp(x, y));
			if (tileSprite)
				this->setPhysicsTile(layer, x, y, 1.1f, 1.1f);
		}
	}
}

void Stage1Scene::setPhysicsTile(cocos2d::CCTMXLayer* layer, int x, int y, float width, float height)
{
	cocos2d::Vec2 p = layer->positionAt(ccp(x, y));
	CCSize tileSize = m_tileMap->getTileSize();

	b2BodyDef bodyDef;
	bodyDef.type = b2_staticBody;
	bodyDef.position.Set((p.x + (tileSize.width / 2.0f)) / PTM_RATIO,
		(p.y + (tileSize.height / 2.0f)) / PTM_RATIO);
	b2Body* body = PhysicsEngine::GetInstance()->getWorld()->CreateBody(&bodyDef);

	b2PolygonShape shape;
	shape.SetAsBox((tileSize.width / PTM_RATIO) * 0.45f * width,
		(tileSize.width / PTM_RATIO) * 0.45f * height);

	b2FixtureDef fixtureDef;
	fixtureDef.shape = &shape;
	fixtureDef.density = 1.0f;
	fixtureDef.friction = 0.3f;
	fixtureDef.restitution = 0.0f;
	fixtureDef.filter.categoryBits = 0x01;
	fixtureDef.filter.maskBits = 0xffff;
	body->CreateFixture(&fixtureDef);
}

cocos2d::Vec2 Stage1Scene::objectOnTileIndex(cocos2d::Vec2 pos)
{
	int x = pos.x / m_tileMap->getTileSize().width;
	int y = ((m_tileMap->getMapSize().height * m_tileMap->getTileSize().height) - pos.y) / m_tileMap->getTileSize().height;
	return Vec2(x, y);
}

void Stage1Scene::update(float deltaTime)
{
	m_player->update(deltaTime);

	m_tileIndex = objectOnTileIndex(m_player->getSprite()->getPosition());
	auto tileGID = m_tileMapLayer->getTileGIDAt(m_tileIndex);
	if (tileGID)	// Ÿ�� �ε����κ��� �ش� Ÿ���� GDI�� �޾ƿ� ���� �����ϸ�
	{
		Value& properties = m_tileMap->getPropertiesForGID(tileGID); // �浹��Ÿ���� �Ӽ��� �����´�.
		if (!properties.isNull())  // �浹�� Ÿ���� �Ӽ��� �ִٸ�
		{
			std::string obstacle = properties.asValueMap()["obstacle"].asString(); // string������ ������ �� �Ӽ��� Obstacle�϶�
			if (obstacle == "YES") // wall�� YES��
			{
			}
		}
	}
	char buf[256];
	sprintf(buf, "Reference (%d,%d)", getReferenceCount(), getReferenceCount());
	m_referenceLabel->setString(buf);
	sprintf(buf, "Tile Index (%.0f,%.0f)", objectOnTileIndex(m_player->getSprite()->getPosition()).x, objectOnTileIndex(m_player->getSprite()->getPosition()).y);
	m_testLabel->setString(buf);
	sprintf(buf, "Mouse Pos (%.0f,%.0f)", m_mousePos.x, m_mousePos.y);
	m_mouseLabel->setString(buf);

	InputManager::GetInstance()->update(deltaTime);
	PhysicsEngine::GetInstance()->update(deltaTime);

	cocos2d::Vec2 pixelVec2 = { m_player->getPhysicsBody()->GetPosition().x*PTM_RATIO+300 , m_player->getPhysicsBody()->GetPosition().y*PTM_RATIO };
	this->setViewPointCenter(pixelVec2);
}

void Stage1Scene::setViewPointCenter(cocos2d::Vec2 position)
{
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();
	int x = MAX(position.x, winSize.width / 2);
	int y = MAX(position.y, winSize.height / 2);
	x = MIN(x, (m_tileMap->getMapSize().width * this->m_tileMap->getTileSize().width) - winSize.width / 2);
	y = MIN(y, (m_tileMap->getMapSize().height * m_tileMap->getTileSize().height) - winSize.height / 2);
	cocos2d::Vec2 actualPosition = ccp(x, y);
	cocos2d::Vec2 centerOfView = ccp(winSize.width / 2, winSize.height / 2);
	cocos2d::Vec2 viewPoint = ccpSub(centerOfView, actualPosition);
	this->setPosition(viewPoint);

	cocos2d::Vec2 uiViewPoint = ccpSub(actualPosition, centerOfView);
	m_referenceLabel->setPosition(Vec2(230, 80) + uiViewPoint);
	m_testLabel->setPosition(Vec2(230, 50) + uiViewPoint);
	m_mouseLabel->setPosition(Vec2(230, 30) + uiViewPoint);
}

void Stage1Scene::menuCloseCallback(Ref* pSender)
{
	Director::getInstance()->end();
}

void Stage1Scene::OnMouseDown(cocos2d::Event* event)
{
	EventMouse* e = (EventMouse*)event;
	m_mousePos.x = e->getCursorX();
	m_mousePos.y = e->getCursorY();
	InputManager::GetInstance()->inputMousePoint({ m_mousePos.x,m_mousePos.y });
}

void Stage1Scene::OnMouseUp(cocos2d::Event* event)
{
	EventMouse* e = (EventMouse*)event;
	m_mousePos.x = e->getCursorX();
	m_mousePos.y = e->getCursorY();
	InputManager::GetInstance()->inputMousePoint({ m_mousePos.x,m_mousePos.y });
}

void Stage1Scene::OnMouseMove(cocos2d::Event* event)
{
	EventMouse* e = (EventMouse*)event;
	m_mousePos.x = e->getCursorX();
	m_mousePos.y = e->getCursorY();
	InputManager::GetInstance()->inputMousePoint({ m_mousePos.x,m_mousePos.y });
}

void Stage1Scene::OnMouseScroll(cocos2d::Event* event)
{
	EventMouse* e = (EventMouse*)event;
	m_mousePos.x = e->getCursorX();
	m_mousePos.y = e->getCursorY();
	InputManager::GetInstance()->inputMousePoint({ m_mousePos.x,m_mousePos.y });
}

void Stage1Scene::release()
{
	m_player->release();
}

void Stage1Scene::OnKeyPress(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event)
{
	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	case EventKeyboard::KeyCode::KEY_UP_ARROW:
	case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
	case EventKeyboard::KeyCode::KEY_V:
	case EventKeyboard::KeyCode::KEY_C:
	case EventKeyboard::KeyCode::KEY_X:
	case EventKeyboard::KeyCode::KEY_SPACE:
		InputManager::GetInstance()->inputDownKey((int)keyCode);	// ���� ���� �ش� Ű�� �ԷµǸ� InputManager�� ��ϵȴ�.
		break;
	case EventKeyboard::KeyCode::KEY_ESCAPE:								// ESCŰ�� ������
		release();															// ���� �޸𸮸� �����ϰ�
		Director::getInstance()->replaceScene(TitleScene::createScene());	// �� ��ȯ
		break;
	}
}

void Stage1Scene::OnKeyUp(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event)
{
	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	case EventKeyboard::KeyCode::KEY_UP_ARROW:
	case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
	case EventKeyboard::KeyCode::KEY_V:
	case EventKeyboard::KeyCode::KEY_C:
	case EventKeyboard::KeyCode::KEY_X:
	case EventKeyboard::KeyCode::KEY_SPACE:
		InputManager::GetInstance()->inputUpKey((int)keyCode);		// ���� ���� �ش� Ű�� �ԷµǸ� InputManager�� ��ϵȴ�.
		break;
	}
}