<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="tileSet" tilewidth="128" tileheight="128" tilecount="240" columns="16">
 <image source="tileSet.png" width="2048" height="1920"/>
 <tile id="96" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="97" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="98" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="99" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="100" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="101" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="102" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="103" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="104" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="105" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="106" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="107" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="108" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="109" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="110" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="111" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="112" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="113" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="114" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="115" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="116" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="117" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="118" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="119" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="120" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="121" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="122" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="123" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="124" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="125" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="126" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="127" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="128" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="129" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="130" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="131" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="132" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="133" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="134" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="135" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="136" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="137" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="138" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="139" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="140" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="141" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="142" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="143" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="144" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="145" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="146" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="147" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="148" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="149" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="150" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="151" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="152" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="153" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="154" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="155" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="156" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="157" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="158" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
 <tile id="159" type="obstacle">
  <properties>
   <property name="obstacle" value="YES"/>
  </properties>
 </tile>
</tileset>
