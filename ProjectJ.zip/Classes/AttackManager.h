#pragma once
#include "cocos2d.h"
#include "SingleTon.h"

class AttackManager : public cocos2d::Layer
{
private:
public:
};