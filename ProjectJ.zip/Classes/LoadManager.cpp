#include "LoadManager.h"

LoadManager::LoadManager()
{
}

LoadManager::~LoadManager()
{
}

void LoadManager::loadTileMap()
{
}