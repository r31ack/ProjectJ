#include "DynamicDebug.h"
USING_NS_CC;

DynamicDebug::DynamicDebug()
{
}
DynamicDebug::~DynamicDebug()
{
}

void DynamicDebug::create()
{
	m_referenceLabel = Label::createWithSystemFont("Reference", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_referenceLabel->setPosition(Vec2(230, 70));
	m_testLabel = Label::createWithSystemFont("Tile", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_testLabel->setPosition(Vec2(230, 50));
	m_mouseLabel = Label::createWithSystemFont("Mouse", "Thonburi", 20, Size(450, 150), TextHAlignment::LEFT);
	m_mouseLabel->setPosition(Vec2(230, 30));
}

void DynamicDebug::update(float deltaTime)
{
	char buf[256];
	sprintf(buf, "Mouse Pos (%.0f,%.0f)", m_mousePos.x, m_mousePos.y);
	m_mouseLabel->setString(buf);
}